export const TUMOR_GROUPS = [
  { id: 'mama',       label: 'Mama',           emoji: '🎗️', color: '#E91E8C' },
  { id: 'pulmao',     label: 'Pulmão',         emoji: '🫁', color: '#1E88E5' },
  { id: 'colorretal', label: 'Colorretal',     emoji: '🟤', color: '#795548' },
  { id: 'prostata',   label: 'Próstata',       emoji: '🔵', color: '#1565C0' },
  { id: 'hemato',     label: 'Hematologia',    emoji: '🩸', color: '#C62828' },
  { id: 'gastrico',   label: 'Gástrico/GEJ',   emoji: '🟡', color: '#F9A825' },
  { id: 'ovario',     label: 'Ovário',         emoji: '🟣', color: '#7B1FA2' },
  { id: 'figado',     label: 'Fígado/Biliar',  emoji: '🟠', color: '#E65100' },
  { id: 'rim',        label: 'Rim/Urológico',  emoji: '🫘', color: '#00838F' },
  { id: 'snc',        label: 'SNC',            emoji: '🧠', color: '#4527A0' },
  { id: 'pele',       label: 'Pele/Melanoma',  emoji: '☀️', color: '#FF8F00' },
  { id: 'outros',     label: 'Outros',         emoji: '🔬', color: '#546E7A' },
]

export const SCENARIOS = [
  'Neoadjuvante', 'Adjuvante', '1ª Linha Metastático',
  '2ª Linha Metastático', '3ª Linha+', 'Localizado', 'Geral'
]

export const THEMES = [
  'CDK4/6', 'Imunoterapia', 'Anti-HER2', 'PARP', 'PI3K/AKT/mTOR',
  'Anti-VEGF', 'ADC', 'Hormonioterapia', 'Quimioterapia', 'Cirurgia/RT',
  'Biomarcadores', 'ESR1/PIK3CA', 'ALK/ROS1/EGFR', 'BRCA', 'Outro'
]

export const SOURCE_TYPES = [
  { id: 'teoc',    label: 'OC-TEOC 2025',       emoji: '📚', color: '#5C6BC0' },
  { id: 'trial',   label: 'Ensaio Clínico',      emoji: '🔬', color: '#00838F' },
  { id: 'review',  label: 'Revisão/Guideline',   emoji: '📋', color: '#43A047' },
  { id: 'case',    label: 'Caso Clínico',         emoji: '🩺', color: '#E65100' },
  { id: 'note',    label: 'Nota Pessoal',         emoji: '✏️', color: '#8D6E63' },
]

export const CARD_COLORS = [
  { id: 'blue',   bg: '#E3F2FD', border: '#1E88E5', text: '#1565C0' },
  { id: 'green',  bg: '#E8F5E9', border: '#43A047', text: '#2E7D32' },
  { id: 'orange', bg: '#FFF3E0', border: '#E65100', text: '#BF360C' },
  { id: 'red',    bg: '#FFEBEE', border: '#D32F2F', text: '#B71C1C' },
  { id: 'purple', bg: '#F3E5F5', border: '#7B1FA2', text: '#6A1B9A' },
  { id: 'teal',   bg: '#E0F2F1', border: '#00838F', text: '#006064' },
]

export const IMPORTANCE = [
  { id: 3, label: '🔴 Alta', color: '#D32F2F' },
  { id: 2, label: '🟡 Média', color: '#F9A825' },
  { id: 1, label: '🟢 Baixa', color: '#43A047' },
]

// Gera ID único
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2)
