const KEY = 'onconotes_v1'

export function loadNotes() {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? JSON.parse(raw) : []
  } catch { return [] }
}

export function saveNotes(notes) {
  try { localStorage.setItem(KEY, JSON.stringify(notes)) } catch {}
}

export function exportJSON(notes) {
  const blob = new Blob([JSON.stringify(notes, null, 2)], { type: 'application/json' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = `onconotes-backup-${new Date().toISOString().slice(0,10)}.json`
  a.click()
}

export function importJSON(file) {
  return new Promise((res, rej) => {
    const r = new FileReader()
    r.onload = (e) => {
      try { res(JSON.parse(e.target.result)) }
      catch { rej(new Error('JSON inválido')) }
    }
    r.onerror = () => rej(new Error('Erro ao ler arquivo'))
    r.readAsText(file)
  })
}
