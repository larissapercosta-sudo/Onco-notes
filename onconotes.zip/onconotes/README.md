# 📓 OncoNotes — Caderno de Estudos Oncológico

Caderno digital para residentes e fellows de oncologia.
Organização tripla: **grupo tumoral × cenário clínico × tema/alvo**.

## ✅ Funcionalidades

- Notas com editor rico (listas, tabelas markdown)
- Classificação por grupo tumoral (12 grupos), cenário clínico e tema/alvo
- 5 fontes: OC-TEOC, Ensaio Clínico, Revisão/Guideline, Caso Clínico, Nota Pessoal
- Código de importância (🔴 Alta / 🟡 Média / 🟢 Baixa)
- Cores customizáveis por card
- Tags livres para busca rápida
- ★ Favoritos
- Busca full-text + filtros múltiplos combinados
- Ordenação por data, importância ou grupo
- Backup/restore em JSON (sem perda de dados)
- PWA: instalável no celular/desktop
- **Dados salvos localmente no navegador** — funciona offline após primeira visita

---

## 🚀 Deploy na Vercel (5 minutos)

### 1. Suba no GitHub
```bash
cd onconotes
git init
git add .
git commit -m "OncoNotes v1.0"
git remote add origin https://github.com/SEU_USUARIO/onconotes.git
git push -u origin main
```

### 2. Deploy
1. [vercel.com](https://vercel.com) → **Add New Project**
2. Conecte o repositório `onconotes`
3. **Sem variáveis de ambiente** — este app não usa API externa
4. Clique em **Deploy**

Seu caderno estará em `https://onconotes.vercel.app`.

> **Dica:** use a URL em qualquer dispositivo. Os dados ficam no localStorage de cada navegador. Use Backup/Importar para sincronizar entre dispositivos.

---

## 💻 Rodar localmente

```bash
npm install
npm run dev
# http://localhost:5173
```

---

## 📁 Estrutura

```
onconotes/
├── src/
│   ├── main.jsx      # Entry point
│   ├── App.jsx       # App completo (formulário, cards, filtros)
│   ├── constants.js  # Grupos, cenários, temas, fontes
│   └── storage.js    # localStorage + backup JSON
├── public/favicon.svg
├── index.html
├── vite.config.js
└── package.json
```

---

## 🔒 Privacidade

Nenhum dado é enviado para servidores externos.
Tudo fica no `localStorage` do seu navegador.
Use o botão **Backup** para exportar um JSON e guardar em nuvem (Google Drive, etc.).
